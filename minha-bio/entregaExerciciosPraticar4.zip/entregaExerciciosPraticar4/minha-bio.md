# Minha bio - Por Jennifer Espindola

## Estudo sobre git e github para aulas da Labenu (Curso Web )

### Bom eu sou a Jennifer

- Gosto de: 
- cachorros
- gatos
- gente
- lasanha
- filmes e séries de crimes reais
- saber o que os outros estão pensando
- não fazer nada
- de frio 
- de rio
- de árvores e plantas em geral
- de coisas fofas (o que engloba quase tudo pq meu fofurômetro é quebrado)
- de pessoas que não tem medo de ser elas mesmas
- da minha família, óbvio...até as partes ruins
- de escrever 
- de aprender 

